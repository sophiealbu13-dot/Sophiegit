const entrada = require('readline-sync');
const veiculo = entrada.question("Nome do veiculo: ");
const n1 = entrada.questionFloat("Placa do veiculo: ");
const n2 = entrada.questionFloat("velocidade: ");
console.log(`\nVelocidade final ${veiculo}: ${velocidade.toFixed(1)}`);
if (media >= 80) {
console.log("SITUACAO: MULTADO! ");
} else if (velocidade >= 80 && velocidade < 80) {
console.log("SITUACAO: MULTADO! ");
} else {
console.log("SITUACAO: CONTINUE SUA VIAGEM!");
} // deu errado

let contador = 0
while (contador <= 100){
    console.log(`Contagem: ${contador}`);
    contador ++ // Isso aumenta 1 ano no contador (IMPOTANTE) 
}