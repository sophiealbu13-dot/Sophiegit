// console.log("Olá, mundo! ");
// console.log("Estou começando a aprender JavaScript. ");
// console.log("Esta é a disciplina de BackEnd 1.");
console.log("Olá, senai! ");
console.log("Estou começando a aprender JavaScript. ");
console.log("A disciplina BackEnd é dificil");
